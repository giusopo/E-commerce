package model;

public interface Cart {

}
