package model;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import model.bean.UserBean;
import model.User;

public class UserModel implements User {

	private static DataSource ds;

    private Connection connection = null;
    private PreparedStatement pstmt = null;
    
    static {
        try {
            Context initCtx = new InitialContext();
            Context envCtx = (Context) initCtx.lookup("java:comp/env");

            ds = (DataSource) envCtx.lookup("jdbc/ecommerce");

        } catch (NamingException e) {
            System.out.println("Error:" + e.getMessage());
        }
    }

    @Override
    public void AddUser(UserBean user) {

        String sql = "INSERT INTO utente (NOME, COGNOME, USER_NAME, DATA_NASCITA, email, password) VALUES (?, ?, ?, ?, ?, ?)";

        try {
            connection = ds.getConnection();

            if (connection != null) {
                pstmt = connection.prepareStatement(sql);

                pstmt.setString(1, user.getNome());
                pstmt.setString(2, user.getCognome());
                pstmt.setString(3, user.getUserName());
                pstmt.setString(4, user.getDataNascita().toString());
                pstmt.setString(5, user.getEmail());
                pstmt.setString(6, user.getPassword());

                //controllo sul numero di righe inserite
                int rowsInserted = pstmt.executeUpdate();

                connection.commit();

                if (rowsInserted > 0) {
                    System.out.println("A new user was inserted successfully!");
                }

            } else {
                System.out.println("problema con la connessione al db");
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);

        } finally {
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) { /* gestione delle eccezioni */ }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) { /* gestione delle eccezioni */ }
            }
        }
    }

    public UserBean getUserBy(String username) {

        UserBean user = new UserBean();

        String sql = "SELECT ID, USER_NAME, password FROM utente WHERE USER_NAME = ?";

        try {
            connection = ds.getConnection();
            pstmt = connection.prepareStatement(sql);
            pstmt.setString(1, username);

            ResultSet rs = pstmt.executeQuery();

            //connection.commit();

            if (rs.next()) {

                user.setID(rs.getInt("ID"));
                user.setUserName(rs.getString("USER_NAME"));
                user.setPassword(rs.getString("password"));
            } else {

                System.out.println("l'utente "+ username +" non è stato trovato");
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);

        } finally {
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    /* gestione delle eccezioni */
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    /* gestione delle eccezioni */
                }
            }
        }

        return user;
    }
}
