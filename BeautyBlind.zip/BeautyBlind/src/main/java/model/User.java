package model;

import model.bean.UserBean;

public interface User {

    public void AddUser(UserBean user);
    
    public UserBean getUserBy(String username);
}
