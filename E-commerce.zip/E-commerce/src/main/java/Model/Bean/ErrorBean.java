package Model.Bean;

public class ErrorBean {

	private int val;
	private String msg;
	
	public ErrorBean(int val, String msg) {
		
		this.val = val;
		this.msg = msg;
	}
	
	public ErrorBean() {
		
		this.val = -1;
		this.msg = "";
	}
	
	public int getVal() {
		return val;
	}
	public void setVal(int val) {
		this.val = val;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	
}
