package Model.Interface;

public interface CartModel_intf {

}
