package Model.Interface;

import Model.Bean.UserBean;

public interface UserModel_intf {

    public void AddUser(UserBean user);
    
    public UserBean getUserBy(String username);
}
