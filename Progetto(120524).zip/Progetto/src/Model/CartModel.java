package Model;

import java.util.ArrayList;
import java.util.List;

import Model.Bean.ProductBean;

public class CartModel {

	private List<ProductBean> products;
	
	public CartModel() {
		products = new ArrayList<ProductBean>();
	}
	
	public void addProduct(ProductBean product) {
		products.add(product);
	}
	
	public void deleteProduct(ProductBean product) {
		for(ProductBean prod : products) {
			if(prod.getID() == product.getID()) {
				products.remove(prod);
				break;
			}
		}
 	}
	
	public List<ProductBean> getProducts() {
		return  products;
	}
}
